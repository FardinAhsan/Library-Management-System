<?php

define("url","http://localhost/lib.ffi.project/Theme/");
define("tempUrlStu","http://localhost/lib.ffi.project/view/Student/")

?>