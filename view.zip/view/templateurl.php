<?php

define("url","http://localhost/lib.ffi.project/Theme/");
define("tempUrl","http://localhost/lib.ffi.project/view/Admin/")

?>